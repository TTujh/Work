import telebot
import time
from telebot import types
import sys
from telebot.apihelper import send_message
from logic import Queue




bot = telebot.TeleBot('8052191124:AAEiSYKHUgH57mEnNJOg3A1JWVCNXFOZE5g')

print(f'[CONSOLE {time.localtime(time.time()).tm_hour}:{time.localtime(time.time()).tm_min}:{time.localtime(time.time()).tm_sec}]: Bot API token connected successfully')

new_queue = Queue()

settings_markup = types.InlineKeyboardMarkup()
btn_settings1 = types.InlineKeyboardButton(text='Все берут по 1 заявке', callback_data='one_ord')
btn_settings2 = types.InlineKeyboardButton(text='Все берут по 2 заявки', callback_data='two_ord')
btn_settings3 = types.InlineKeyboardButton(text='Все берут по 3 заявки', callback_data='three_ord')
settings_markup.add(btn_settings1, btn_settings2, btn_settings3)

markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
button_1 = types.KeyboardButton('Добрал!')
button_2 = types.KeyboardButton('Показать текущий порядок очереди')
button_3 = types.KeyboardButton('Встать в конец очереди')
button_4 = types.KeyboardButton('Пропустить ход')
button_5 = types.KeyboardButton('Покинуть очередь')
button_6 = types.KeyboardButton('Напоминание')
markup.add(button_1, button_2, button_3, button_4, button_5, button_6)

last_orders : int

try:
    @bot.message_handler(commands=['settings'], content_types=['text'])
    def settings(message):
        global new_queue

        markup = types.InlineKeyboardMarkup()
        bnt1 = types.InlineKeyboardButton(text='Количество добираемых заявок', callback_data='order_count')
        bnt2 = types.InlineKeyboardButton(text='Coming soon...', callback_data='NoneType1')
        bnt3 = types.InlineKeyboardButton(text='Coming soon...', callback_data='NoneType2')
        markup.add(bnt1, bnt2, bnt3)
        send_message = '<b>Настройка очереди</b>'
        bot.send_message(message.chat.id, send_message, parse_mode='html', reply_markup=markup)


    @bot.message_handler(commands=['save'], content_types=['text'])
    def save(message):
        global new_queue

        send_message = '<b>Порядок сохранен</b>'
        bot.send_message(message.chat.id, send_message, parse_mode='html')
        raise Exception

    @bot.callback_query_handler(func=lambda call: True)
    def inline_answer_call(call):
        if call.data == 'order_count':
            send_message = '<b>Настройка очереди</b>'
            bot.send_message(call.message.chat.id, send_message, parse_mode='html', reply_markup=settings_markup)

        elif call.data == 'one_ord':
            new_queue.count_orders = 1
            for i in range(len(new_queue.active_queue)):
                new_queue.active_queue[i][2] = 0
            send_message = '<b>Очередь настроена. Все берут по 1 заявке</b>'
            bot.send_message(call.message.chat.id, send_message, parse_mode='html', reply_markup=markup)

        elif call.data == 'two_ord':
            new_queue.count_orders = 2
            for i in range(len(new_queue.active_queue)):
                new_queue.active_queue[i][2] = 0
            send_message = '<b>Очередь настроена. Все берут по 2 заявки</b>'
            bot.send_message(call.message.chat.id, send_message, parse_mode='html', reply_markup=markup)

        elif call.data == 'three_ord':
            new_queue.count_orders = 3
            for i in range(len(new_queue.active_queue)):
                new_queue.active_queue[i][2] = 0
            send_message = '<b>Очередь настроена. Все берут по 3 заявки</b>'
            bot.send_message(call.message.chat.id, send_message, parse_mode='html', reply_markup=markup)


    @bot.message_handler(commands=['clear'], content_types=['text', 'stickers'])
    def clear_queue(message):
        global new_queue

        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        button_1 = types.KeyboardButton('Добрал!')
        button_2 = types.KeyboardButton('Показать текущий порядок очереди')
        button_3 = types.KeyboardButton('Встать в конец очереди')
        button_4 = types.KeyboardButton('Пропустить ход')
        button_5 = types.KeyboardButton('Покинуть очередь')
        button_6 = types.KeyboardButton('Напоминание')
        markup.add(button_1, button_2, button_3, button_4, button_5, button_6)

        send_message = new_queue.clear_queue()
        bot.send_message(message.chat.id, send_message, parse_mode='html', reply_markup=markup)

    @bot.message_handler(content_types=['text', 'sticker'])
    def get_text_messages(message):
        global new_queue

        if message.text == 'Встать в конец очереди':

            markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
            button_1 = types.KeyboardButton('Добрал!')
            button_2 = types.KeyboardButton('Показать текущий порядок очереди')
            button_3 = types.KeyboardButton('Встать в конец очереди')
            button_4 = types.KeyboardButton('Пропустить ход')
            button_5 = types.KeyboardButton('Покинуть очередь')
            button_6 = types.KeyboardButton('Напоминание')
            markup.add(button_1, button_2, button_3, button_4, button_5, button_6)

            send_message = new_queue.add_new_person_to_queue([message.from_user.username, message.from_user.first_name, 0])

            bot.send_message(message.chat.id, send_message, parse_mode='html', reply_markup=markup)

        elif message.text == 'Показать текущий порядок очереди':
            markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
            button_1 = types.KeyboardButton('Добрал!')
            button_2 = types.KeyboardButton('Показать текущий порядок очереди')
            button_3 = types.KeyboardButton('Встать в конец очереди')
            button_4 = types.KeyboardButton('Пропустить ход')
            button_5 = types.KeyboardButton('Покинуть очередь')
            button_6 = types.KeyboardButton('Напоминание')
            markup.add(button_1, button_2, button_3, button_4, button_5, button_6)

            send_message = new_queue.get_queue_order()

            bot.send_message(message.chat.id, send_message, parse_mode='html', reply_markup=markup)

        elif message.text == 'Покинуть очередь':
            markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
            button_1 = types.KeyboardButton('Добрал!')
            button_2 = types.KeyboardButton('Показать текущий порядок очереди')
            button_3 = types.KeyboardButton('Встать в конец очереди')
            button_4 = types.KeyboardButton('Пропустить ход')
            button_5 = types.KeyboardButton('Покинуть очередь')
            button_6 = types.KeyboardButton('Напоминание')
            markup.add(button_1, button_2, button_3, button_4, button_5, button_6)


            send_message = new_queue.remove_person_from_queue([message.from_user.username, message.from_user.first_name])

            bot.send_message(message.chat.id, send_message, parse_mode='html', reply_markup=markup)

        elif message.text == 'Пропустить ход':
            global last_orders
            markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
            button_1 = types.KeyboardButton('Добрал!')
            button_2 = types.KeyboardButton('Показать текущий порядок очереди')
            button_3 = types.KeyboardButton('Встать в конец очереди')
            button_4 = types.KeyboardButton('Пропустить ход')
            button_5 = types.KeyboardButton('Покинуть очередь')
            button_6 = types.KeyboardButton('Напоминание')

            markup.add(button_1, button_2, button_3, button_4, button_5, button_6)

            send_message = 'Error'
            for i in new_queue.active_queue:
                if message.from_user.username in i:
                    send_message = new_queue.swap_queue_order(i)
                else:
                    send_message = new_queue.swap_queue_order([message.from_user.username, message.from_user.first_name])


            bot.send_message(message.chat.id, send_message, parse_mode='html', reply_markup=markup)

        elif message.text == 'Добрал!':
            markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
            button_1 = types.KeyboardButton('Добрал!')
            button_2 = types.KeyboardButton('Показать текущий порядок очереди')
            button_3 = types.KeyboardButton('Встать в конец очереди')
            button_4 = types.KeyboardButton('Пропустить ход')
            button_5 = types.KeyboardButton('Покинуть очередь')
            button_6 = types.KeyboardButton('Напоминание')
            markup.add(button_1, button_2, button_3, button_4, button_5, button_6)

            pre_send_1 = new_queue.dobral([message.from_user.username, message.from_user.first_name, 0])

            send_message = f'{pre_send_1}'

            bot.send_message(message.chat.id, send_message, parse_mode='html', reply_markup=markup)

        elif message.text == 'Напоминание':
            markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
            button_1 = types.KeyboardButton('Добрал!')
            button_2 = types.KeyboardButton('Показать текущий порядок очереди')
            button_3 = types.KeyboardButton('Встать в конец очереди')
            button_4 = types.KeyboardButton('Пропустить ход')
            button_5 = types.KeyboardButton('Покинуть очередь')
            button_6 = types.KeyboardButton('Напоминание')
            markup.add(button_1, button_2, button_3, button_4, button_5, button_6)

            send_message = new_queue.notification()

            bot.send_message(message.chat.id, send_message, parse_mode='html', reply_markup=markup)


    if __name__ == '__main__':
        while True:
            try:
                bot.polling(none_stop=True, timeout=123)
            except Exception as err:
                print(f'[CONSOLE {time.localtime(time.time()).tm_hour}:{time.localtime(time.time()).tm_min}:{time.localtime(time.time()).tm_sec}]: ERROR {err}')
                print(f'[CONSOLE {time.localtime(time.time()).tm_hour}:{time.localtime(time.time()).tm_min}:{time.localtime(time.time()).tm_sec}]: Saving last queue order...')
                new_queue.write_config()
                new_queue.crush()
                print(f'[CONSOLE {time.localtime(time.time()).tm_hour}:{time.localtime(time.time()).tm_min}:{time.localtime(time.time()).tm_sec}]: Complete')
                print(f'[CONSOLE {time.localtime(time.time()).tm_hour}:{time.localtime(time.time()).tm_min}:{time.localtime(time.time()).tm_sec}]: Auto restart within 5 seconds')
                time.sleep(5)



finally:
    print(f'[CONSOLE {time.localtime(time.time()).tm_hour}:{time.localtime(time.time()).tm_min}:{time.localtime(time.time()).tm_sec}]: Saving last queue order...')
    new_queue.write_config()
    new_queue.crush()
    print(f'[CONSOLE {time.localtime(time.time()).tm_hour}:{time.localtime(time.time()).tm_min}:{time.localtime(time.time()).tm_sec}]: Complete')
