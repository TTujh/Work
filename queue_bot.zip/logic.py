import os
import configparser


class Queue:

    def __init__(self):
        self.active_queue = self._write_new_order()
        self.count_orders = self._parse_config()

    @staticmethod
    def _resource_path(relative_path):
        """ Get absolute path to resource, works for dev and for PyInstaller """
        base_path = os.getcwd()
        return os.path.join(base_path, relative_path)

    def write_config(self):
        truepath = Queue._resource_path("config.ini")
        config = configparser.ConfigParser()
        config.add_section("Settings")
        config.set('Settings', 'order_count', f'{self.count_orders}')
        with open(truepath, 'w') as config_file:
            config.write(config_file)

    def _parse_config(self):
        truepath = Queue._resource_path("config.ini")
        config = configparser.ConfigParser()
        config.read(truepath)
        stdout = config.get('Settings', 'order_count')
        return int(stdout)

    def _write_new_order(self):
        """Parse curr_que.txt for last queue order"""
        truepath = Queue._resource_path("curr_que.txt")
        with open(truepath, "r") as curr_queue:
            try:
                sdtin = list()
                list_queue = curr_queue.read()
                if list_queue == '':
                    return []
                for i in list_queue.split('\n'):
                    if i != '':
                        answer = i.split('\t')
                        sdtin.append([answer[0], answer[1], int(answer[2])])
            except IndexError:
                return []
            return sdtin

    def crush(self):
        """Write in curr_que.txt last queue order"""
        truepath = Queue._resource_path("curr_que.txt")
        with open(truepath, "w") as curr_queue:
            stdout = ''
            for i in range(len(self.active_queue)):
                stdout += f'{self.active_queue[i][0]}\t{self.active_queue[i][1]}\t{self.active_queue[i][2]}\n'
            curr_queue.write(stdout)

    def add_new_person_to_queue(self, telegram_tag):

        for i in self.active_queue:

            if telegram_tag[0] in i:

                return f"<b>❌ {telegram_tag[1]} вы уже в очереди</b>"

        else:
            self.active_queue.append(telegram_tag)
            return f"<b>✅ {telegram_tag[1]} встал в очередь</b>"

    def remove_person_from_queue(self, telegram_tag):
        for i in self.active_queue:

            if telegram_tag[0] in i:
                self.active_queue.remove(i)
                return f"<b>✅ {telegram_tag[1]} покинул очередь</b>"
        else:
            return f"<b>❌ {telegram_tag[1]} вы еще не находитесь в очереди</b>"

    def swap_queue_order(self, telegram_tag):
        if telegram_tag in self.active_queue:
            self.active_queue.remove(telegram_tag)
            self.active_queue.append(telegram_tag)
            return f"<b>{telegram_tag[1]} передает свой ход следующему</b>"
        else:
            return f"<b>❌ {telegram_tag[1]} вы еще не находитесь в очереди</b>"

    def dobral(self, telegram_tag):
        for i in range(len(self.active_queue)):
            if telegram_tag[0] in self.active_queue[i]:
                self.active_queue[i][2] += 1
                if self.active_queue[i][2] == self.count_orders:
                    self.active_queue.remove(self.active_queue[i])
                    self.active_queue.append(telegram_tag)
                    return f"<b>✅ {telegram_tag[1]} добрал все свои заявки\n{self.notification()}</b>"
                else:
                    return f"<b>✅ {telegram_tag[1]} добрал [{self.active_queue[i][2]}/{self.count_orders}].</b>"

        return f"<b>❌ {telegram_tag[1]} вы еще не находитесь в очереди</b>"

    def clear_queue(self):
        self.active_queue.clear()
        return '<b>✅ Очередь удалена</b>'

    def get_queue_order(self):
        stdout = ''
        count = 1
        if len(self.active_queue) == 0:
            return '<b>В очереди пока нет участников</b>'
        else:
            for i in self.active_queue:
                if count == 1:
                    stdout += f'<b>🚩{i[1]} [{i[2]}/{self.count_orders}]\n\n</b>'
                else:
                    stdout += f'{i[1]} [{i[2]}/{self.count_orders}]\n'
                count += 1
            return stdout

    def notification(self):
        if len(self.active_queue) <= 1:
            return '<b>❌ В очереди один или менее участников</b>'
        else:
            return f'<b>Ваш черед брать заявки @{self.active_queue[0][0]}</b>'